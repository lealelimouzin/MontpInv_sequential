/*
 * ExchangeFunctions.h
 *
 *  Created on: May 27, 2013
 *      Author: delphineroubinet
 */

#ifndef EXCHANGEFUNCTIONS_H_
#define EXCHANGEFUNCTIONS_H_

#include "../DFNModel/NetworkMeshes.h"


double ReturnAlphaBlock(double,double,double,NetworkMeshes);
double ReturnAvDist(double,double,double,NetworkMeshes,double&,double&);

#endif /* EXCHANGEFUNCTIONS_H_ */
