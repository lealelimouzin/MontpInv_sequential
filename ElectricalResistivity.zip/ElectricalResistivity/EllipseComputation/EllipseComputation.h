/*
 * EllipseComputation.h
 *
 *  Created on: May 1, 2013
 *      Author: delphineroubinet
 */

#ifndef ELLIPSECOMPUTATION_H_
#define ELLIPSECOMPUTATION_H_

#include "../InputOutput/Parameters.h"
#include "../DomainDefinition/Domain.h"


void EllipseComputation(Parameters,Domain,std::string);

#endif /* ELLIPSECOMPUTATION_H_ */
