/*
 * LinearSystem.h
 *
 *  Created on: Apr 22, 2013
 *      Author: delphineroubinet
 */

#ifndef LINEARSYSTEM_H_
#define LINEARSYSTEM_H_

#include "../Storage/UblasStructures.h"

ublas_vector LinearSystemSolving(ublas_matrix, ublas_vector);


#endif /* LINEARSYSTEM_H_ */
