/*
 * Operations.h
 *
 *  Created on: May 27, 2013
 *      Author: delphineroubinet
 */

#ifndef OPERATIONS_H_
#define OPERATIONS_H_


double Harmonic_Mean(double,double);
double Arithmic_Mean(double,double);


#endif /* OPERATIONS_H_ */
